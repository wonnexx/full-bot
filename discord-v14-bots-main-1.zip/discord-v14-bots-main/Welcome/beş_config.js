module.exports = {
  presence: "Luppux", // Bot Durumu
  guildID: "", // Sunucu ID'si
  mp3: true, // mp3 mü Yoksa Youtube Üzerindenmi Çalmasını İsterseniz Burdan true veya false Yazın.
  file: "./ses.mp3", // mp3'ü Seçtiyseniz Ses Dosyasının Uzantısı
  staffRole: "",//En Alt Yetkili Rol ID'si
  youtubeURL: "https://www.youtube.com/watch?v=pQ_T0EiWccM", // Youtube'u Seçtiyseniz Bir Youtube URL'si
  tokens: [ // Tokenler ["55555","5555"] Şeklinde Giriniz.
    "",
    
  ],
  channels: [ // Welcome Kanallarının ID'leri ["55555","5555"] Şeklinde Giriniz.
    "",
    
  ]
}