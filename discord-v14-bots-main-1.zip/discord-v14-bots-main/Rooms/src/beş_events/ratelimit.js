module.exports = async function(RateLimitData) {console.log("[BEŞ - RATE LIMIT]", RateLimitData)}
module.exports.conf = {name: "rateLimit"}
